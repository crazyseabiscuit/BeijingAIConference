﻿==============
python要求
==============
python 2.7
pandas 
matplotlib



==============
运行方式
==============
推荐通过安装Anaconda运行Jupyter notebook；
依次打开如下三个文件，逐行运行并观察结果：
1_preprocess.ipynb
2_KS_IV.ipynb
3_PSI.ipynb


如果没有安装Anaconda,可直接打开终端；
cd至src/目录下，
依次输入如下三个命令：
python 1_preprocess,py
，python 2_KS_IV.py
，python 3_PSI.py
，python 4_Stacking观察终端输出结果和output目录下的输出图片。